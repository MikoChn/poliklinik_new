<?php
include_once("koneksi.php");
session_start();

// Validasi session untuk role admin
if (!isset($_SESSION['loggedin']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

// Logout logic
if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: login.php");
    exit;
}

// Hapus data pasien dengan konfirmasi
if (isset($_GET['aksi']) && $_GET['aksi'] === 'hapus' && isset($_GET['id'])) {
    $stmt = $mysqli->prepare("DELETE FROM pasien WHERE id = ?");
    $stmt->bind_param("i", $_GET['id']);
    if ($stmt->execute()) {
        echo "<script>alert('Data berhasil dihapus'); location.href='manage_pasien.php';</script>";
    }
}

// Proses simpan atau update data pasien
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'] ?? null;
    $nama = htmlspecialchars($_POST['nama'], ENT_QUOTES);
    $alamat = htmlspecialchars($_POST['alamat'], ENT_QUOTES);
    $no_hp = filter_var($_POST['no_hp'], FILTER_SANITIZE_NUMBER_INT);
    $alergi = htmlspecialchars($_POST['alergi'], ENT_QUOTES);

    if ($id) {
        // Update data pasien
        $stmt = $mysqli->prepare("UPDATE pasien SET nama = ?, alamat = ?, no_hp = ?, alergi = ? WHERE id = ?");
        $stmt->bind_param("ssssi", $nama, $alamat, $no_hp, $alergi, $id);
    } else {
        // Insert data pasien baru
        $stmt = $mysqli->prepare("INSERT INTO pasien (nama, alamat, no_hp, alergi) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $nama, $alamat, $no_hp, $alergi);
    }
    if ($stmt->execute()) {
        echo "<script>alert('Data berhasil disimpan'); location.href='manage_pasien.php';</script>";
    }
}

// Fetch data pasien untuk edit
$editData = null;
if (isset($_GET['id'])) {
    $stmt = $mysqli->prepare("SELECT * FROM pasien WHERE id = ?");
    $stmt->bind_param("i", $_GET['id']);
    $stmt->execute();
    $result = $stmt->get_result();
    $editData = $result->fetch_assoc();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Pasien - Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            display: flex;
        }
        .sidebar {
            width: 250px;
            background-color: #343a40;
            color: #fff;
            min-height: 100vh;
        }
        .sidebar a {
            color: #fff;
            text-decoration: none;
            display: block;
            padding: 15px;
        }
        .sidebar a:hover {
            background-color: #495057;
        }
        .content {
            flex-grow: 1;
            padding: 20px;
        }
        .table-container { margin-top: 20px; }
    </style>
</head>
<body>

<!-- Sidebar -->
<div class="sidebar">
    <h3 class="text-center py-3">Sistem Poliklinik</h3>
    <a href="admin_dashboard.php">Dashboard</a>
    <a href="manage_pasien.php">Manage Pasien</a>
    <a href="manage_dokter.php">Manage Dokter</a>
    <a href="manage_poli.php">Manage Poli</a>
    <a href="manage_obat.php">Manage Obat</a>
    <a href="logout.php">Log out</a>
</div>


<div class="content">
    <h2>Manage Pasien</h2>

    <!-- Form Input Data -->
    <form class="row" method="POST" action="">
        <input type="hidden" name="id" value="<?php echo $editData['id'] ?? ''; ?>">

        <div class="form-group mb-3">
            <label for="inputNama" class="form-label">Nama</label>
            <input type="text" class="form-control" name="nama" id="inputNama" placeholder="Nama" value="<?php echo $editData['nama'] ?? ''; ?>" required>
        </div>
        <div class="form-group mb-3">
            <label for="inputAlamat" class="form-label">Alamat</label>
            <input type="text" class="form-control" name="alamat" id="inputAlamat" placeholder="Alamat" value="<?php echo $editData['alamat'] ?? ''; ?>" required>
        </div>
        <div class="form-group mb-3">
            <label for="inputNoHp" class="form-label">Nomor HP</label>
            <input type="text" class="form-control" name="no_hp" id="inputNoHp" placeholder="Nomor HP" value="<?php echo $editData['no_hp'] ?? ''; ?>" required>
        </div>
        <div class="form-group mb-3">
            <label for="inputAlergi" class="form-label">Alergi Obat</label>
            <input type="text" class="form-control" name="alergi" id="inputAlergi" placeholder="Alergi" value="<?php echo $editData['alergi'] ?? ''; ?>">
        </div>
        <button type="submit" class="btn btn-primary">Simpan</button>
    </form>

    <!-- Tabel Data Pasien -->
    <div class="table-responsive mt-4">
        <table class="table table-hover">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama</th>
                    <th>Alamat</th>
                    <th>Nomor HP</th>
                    <th>Alergi</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $stmt = $mysqli->prepare("SELECT * FROM pasien");
                $stmt->execute();
                $result = $stmt->get_result();
                $no = 1;
                while ($data = $result->fetch_assoc()) {
                    echo "<tr>
                        <td>{$no}</td>
                        <td>" . htmlspecialchars($data['nama']) . "</td>
                        <td>" . htmlspecialchars($data['alamat']) . "</td>
                        <td>" . htmlspecialchars($data['no_hp']) . "</td>
                        <td>" . htmlspecialchars($data['alergi']) . "</td>
                        <td>
                            <a class='btn btn-success btn-sm' href='?id={$data['id']}'>Ubah</a>
                            <a class='btn btn-danger btn-sm' onclick=\"return confirm('Yakin ingin menghapus data ini?');\" href='?id={$data['id']}&aksi=hapus'>Hapus</a>
                        </td>
                    </tr>";
                    $no++;
                }
                ?>
            </tbody>
        </table>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
