<?php
include_once("koneksi.php");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register Pasien</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="index.php">Sistem Informasi Poliklinik</a>
        </div>
    </nav>

    <div class="container mt-5">
        <h2>Register Pasien</h2>
        <form method="POST" action="">
            <div class="mb-3">
                <label for="nama" class="form-label">Nama</label>
                <input type="text" class="form-control" name="nama" id="nama" placeholder="Masukkan nama" required>
            </div>
            <div class="mb-3">
                <label for="alamat" class="form-label">Alamat</label>
                <input type="text" class="form-control" name="alamat" id="alamat" placeholder="Masukkan alamat" required>
            </div>
            <div class="mb-3">
                <label for="no_hp" class="form-label">Nomor HP</label>
                <input type="text" class="form-control" name="no_hp" id="no_hp" placeholder="Masukkan nomor HP" required>
            </div>
            <div class="mb-3">
                <label for="alergi" class="form-label">Alergi</label>
                <input type="text" class="form-control" name="alergi" id="alergi" placeholder="Masukkan alergi (jika ada)">
            </div>
            <button type="submit" name="daftar" class="btn btn-primary">Daftar</button>
        </form>

        <?php
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['daftar'])) {
            $nama = $_POST['nama'];
            $alamat = $_POST['alamat'];
            $no_hp = $_POST['no_hp'];
            $alergi = $_POST['alergi'];

            if (empty($nama) || empty($alamat) || empty($no_hp)) {
                echo "<div class='alert alert-danger mt-3'>Harap lengkapi semua data.</div>";
            } else {
                $stmt = $mysqli->prepare("INSERT INTO pasien (nama, alamat, no_hp, alergi) VALUES (?, ?, ?, ?)");
                $stmt->bind_param("ssss", $nama, $alamat, $no_hp, $alergi);
                if ($stmt->execute()) {
                    echo "<div class='alert alert-success mt-3'>Registrasi berhasil! Silakan <a href='index.php?page=login_pasien'>login</a>.</div>";
                } else {
                    echo "<div class='alert alert-danger mt-3'>Registrasi gagal, coba lagi.</div>";
                }
            }
        }
        ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
