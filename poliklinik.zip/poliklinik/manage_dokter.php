<?php
include_once("koneksi.php");
session_start();

// Cek apakah admin sudah login
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true || $_SESSION['role'] !== 'admin') {
    header("Location: ../index.php?page=loginUser");
    exit;
}

// Proses tambah atau update data dokter
if (isset($_POST['simpan'])) {
    $nama = $_POST['nama'];
    $alamat = $_POST['alamat'];
    $no_hp = $_POST['no_hp'];
    $spesialis = $_POST['spesialis'];

    if (isset($_POST['id']) && $_POST['id'] != '') {
        $id = $_POST['id'];
        $query = "UPDATE dokter SET nama='$nama', alamat='$alamat', no_hp='$no_hp', spesialis='$spesialis' WHERE id='$id'";
    } else {
        $query = "INSERT INTO dokter (nama, alamat, no_hp, spesialis) VALUES ('$nama', '$alamat', '$no_hp', '$spesialis')";
    }

    if (mysqli_query($mysqli, $query)) {
        echo "<script>alert('Data dokter berhasil disimpan!'); window.location = 'manage_dokter.php';</script>";
    } else {
        echo "<script>alert('Terjadi kesalahan. Gagal menyimpan data.');</script>";
    }
}

// Proses hapus dokter
if (isset($_GET['aksi']) && $_GET['aksi'] == 'hapus' && isset($_GET['id'])) {
    $id = $_GET['id'];
    $query = "DELETE FROM dokter WHERE id='$id'";
    if (mysqli_query($mysqli, $query)) {
        echo "<script>alert('Data dokter berhasil dihapus!'); window.location = 'manage_dokter.php';</script>";
    }
}

// Ambil data dokter untuk ditampilkan
$query = "SELECT * FROM dokter ORDER BY nama ASC";
$result = mysqli_query($mysqli, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Dokter</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            display: flex;
        }
        .sidebar {
            width: 250px;
            background-color: #343a40;
            color: #fff;
            min-height: 100vh;
        }
        .sidebar a {
            color: #fff;
            text-decoration: none;
            display: block;
            padding: 15px;
        }
        .sidebar a:hover {
            background-color: #495057;
        }
        .content {
            flex-grow: 1;
            padding: 20px;
        }
        .table-container { margin-top: 20px; }
    </style>
</head>
<body>

<!-- Sidebar -->
<div class="sidebar">
    <h3 class="text-center py-3">Sistem Poliklinik</h3>
    <a href="admin_dashboard.php">Dashboard</a>
    <a href="manage_pasien.php">Manage Pasien</a>
    <a href="manage_dokter.php">Manage Dokter</a>
    <a href="manage_poli.php">Manage Poli</a>
    <a href="manage_obat.php">Manage Obat</a>
    <a href="logout.php">Log out</a>
</div>

<!-- Main Content -->
<div class="content">
    <h2>Manage Dokter</h2>

    <!-- Form untuk tambah/ubah data dokter -->
    <div class="card mb-4">
        <div class="card-header">Tambah / Ubah Dokter</div>
        <div class="card-body">
            <form method="POST" action="manage_dokter.php">
                <?php if (isset($_GET['id'])): ?>
                    <?php
                        $id = $_GET['id'];
                        $result = mysqli_query($mysqli, "SELECT * FROM dokter WHERE id='$id'");
                        $dokter = mysqli_fetch_assoc($result);
                    ?>
                    <input type="hidden" name="id" value="<?php echo $dokter['id']; ?>">
                <?php endif; ?>
                <div class="mb-3">
                    <label for="nama" class="form-label">Nama</label>
                    <input type="text" class="form-control" id="nama" name="nama" required
                           value="<?php echo isset($dokter) ? $dokter['nama'] : ''; ?>">
                </div>
                <div class="mb-3">
                    <label for="alamat" class="form-label">Alamat</label>
                    <input type="text" class="form-control" id="alamat" name="alamat" required
                           value="<?php echo isset($dokter) ? $dokter['alamat'] : ''; ?>">
                </div>
                <div class="mb-3">
                    <label for="no_hp" class="form-label">No HP</label>
                    <input type="text" class="form-control" id="no_hp" name="no_hp" required
                           value="<?php echo isset($dokter) ? $dokter['no_hp'] : ''; ?>">
                </div>
                <div class="mb-3">
                    <label for="spesialis" class="form-label">Spesialisasi</label>
                    <select class="form-control" id="spesialis" name="spesialis" required>
                        <option value="Dokter Umum" <?php echo isset($dokter) && $dokter['spesialis'] == 'Dokter Umum' ? 'selected' : ''; ?>>Dokter Umum</option>
                        <option value="Dokter Gigi" <?php echo isset($dokter) && $dokter['spesialis'] == 'Dokter Gigi' ? 'selected' : ''; ?>>Dokter Gigi</option>
                        <option value="Dokter Spesialis" <?php echo isset($dokter) && $dokter['spesialis'] == 'Dokter Spesialis' ? 'selected' : ''; ?>>Dokter Spesialis</option>
                    </select>
                </div>
                <button type="submit" name="simpan" class="btn btn-primary">Simpan</button>
            </form>
        </div>
    </div>

    <!-- Tabel Daftar Dokter -->
    <div class="table-container">
        <table class="table table-hover">
            <thead>
                <tr>
                    <th scope="col">No</th>
                    <th scope="col">Nama</th>
                    <th scope="col">Alamat</th>
                    <th scope="col">Nomor HP</th>
                    <th scope="col">Spesialisasi</th>
                    <th scope="col">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $no = 1; while ($data = mysqli_fetch_assoc($result)): ?>
                    <tr>
                        <th scope="row"><?php echo $no++; ?></th>
                        <td><?php echo $data['nama']; ?></td>
                        <td><?php echo $data['alamat']; ?></td>
                        <td><?php echo $data['no_hp']; ?></td>
                        <td><?php echo $data['spesialis']; ?></td>
                        <td>
                            <a href="manage_dokter.php?id=<?php echo $data['id']; ?>" class="btn btn-warning btn-sm">Ubah</a>
                            <a href="manage_dokter.php?id=<?php echo $data['id']; ?>&aksi=hapus" class="btn btn-danger btn-sm" onclick="return confirm('Apakah Anda yakin ingin menghapus dokter ini?')">Hapus</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
