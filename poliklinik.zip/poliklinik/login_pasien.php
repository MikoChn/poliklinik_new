<?php
include_once("koneksi.php");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Pasien</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="index.php">Sistem Informasi Poliklinik</a>
        </div>
    </nav>

    <div class="container mt-5">
        <h2>Login Pasien</h2>
        <form method="POST" action="">
            <div class="mb-3">
                <label for="no_hp" class="form-label">Nomor HP</label>
                <input type="text" class="form-control" name="no_hp" id="no_hp" placeholder="Masukkan nomor HP" required>
            </div>
            <button type="submit" name="login" class="btn btn-primary">Login</button>
        </form>

        <?php
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login'])) {
            $no_hp = $_POST['no_hp'];

            $stmt = $mysqli->prepare("SELECT * FROM pasien WHERE no_hp = ?");
            $stmt->bind_param("s", $no_hp);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                $_SESSION['pasien'] = $result->fetch_assoc();
                echo "<script>location.href='pasien_dashboard.php';</script>";
            } else {
                echo "<div class='alert alert-danger mt-3'>Login gagal. Nomor HP tidak terdaftar.</div>";
            }
        }
        ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
