<?php
// Koneksi ke database
include_once("koneksi.php");

// Mengambil jumlah dokter, pasien, poli, dan obat
$jumlah_dokter = mysqli_num_rows(mysqli_query($mysqli, "SELECT * FROM dokter"));
$jumlah_pasien = mysqli_num_rows(mysqli_query($mysqli, "SELECT * FROM pasien"));
$jumlah_poli = mysqli_num_rows(mysqli_query($mysqli, "SELECT * FROM periksa"));
$jumlah_obat = mysqli_num_rows(mysqli_query($mysqli, "SELECT * FROM obat"));
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            display: flex;
        }
        .sidebar {
            width: 250px;
            background-color: #343a40;
            color: #fff;
            min-height: 100vh;
        }
        .sidebar a {
            color: #fff;
            text-decoration: none;
            display: block;
            padding: 15px;
        }
        .sidebar a:hover {
            background-color: #495057;
        }
        .content {
            flex-grow: 1;
            padding: 20px;
        }
        .card {
            border: none;
            border-radius: 10px;
            color: #fff;
        }
        .card.bg-blue {
            background-color: #17a2b8;
        }
        .card.bg-green {
            background-color: #28a745;
        }
        .card.bg-yellow {
            background-color: #ffc107;
        }
        .card.bg-red {
            background-color: #dc3545;
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <h3 class="text-center py-3">Sistem Poliklinik</h3>
        <a href="admin_dashboard.php">Dashboard</a>
        <a href="manage_pasien.php">Manage Pasien</a>
        <a href="manage_dokter.php">Manage Dokter</a>
        <a href="manage_poli.php">Manage Poli</a>
        <a href="manage_obat.php">Manage Obat</a>
        <a href="logout.php">Log out</a>
    </div>

    <!-- Main Content -->
    <div class="content">
        <h2 class="text-center mb-4">Admin Dashboard</h2>
        <div class="row">
            <div class="col-md-3">
                <div class="card bg-blue">
                    <div class="card-body text-center">
                        <h3><?php echo $jumlah_dokter; ?></h3>
                        <p>Dokter</p>
                        <a href="manage_dokter.php" class="btn btn-light btn-sm">More info</a>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card bg-green">
                    <div class="card-body text-center">
                        <h3><?php echo $jumlah_pasien; ?></h3>
                        <p>Pasien</p>
                        <a href="manage_pasien.php" class="btn btn-light btn-sm">More info</a>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card bg-yellow">
                    <div class="card-body text-center">
                        <h3><?php echo $jumlah_poli; ?></h3>
                        <p>Poli</p>
                        <a href="manage_poli.php" class="btn btn-light btn-sm">More info</a>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card bg-red">
                    <div class="card-body text-center">
                        <h3><?php echo $jumlah_obat; ?></h3>
                        <p>Obat</p>
                        <a href="manage_obat.php" class="btn btn-light btn-sm">More info</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
